@echo off
TITLE Deploy Farm.IOT to Firebase Hosting
COLOR 0A
echo ==============================================================================
echo        Farm.IOT / Solar.IOT - 1-Click Firebase Hosting Deployer
echo ==============================================================================
echo.
echo Target Project: solariot-374e7
echo Public Directory: ./dist (Pre-compiled production build)
echo.

WHERE npx >nul 2>nul
IF %ERRORLEVEL% NEQ 0 (
    COLOR 0C
    echo [ERROR] Node.js / npx was not detected on your computer!
    echo Please install Node.js from https://nodejs.org and then run this script again.
    echo.
    pause
    exit /b 1
)

echo [Step 1/2] Authenticating with Firebase...
echo (A browser window will open if you are not logged in yet. Log in with your secondary Firebase account)
echo.
call npx -y firebase-tools login

echo.
echo [Step 2/2] Publishing files to Firebase Hosting (solariot-374e7)...
echo.
call npx -y firebase-tools deploy --only hosting --project solariot-374e7

if %ERRORLEVEL% EQU 0 (
    COLOR 0A
    echo.
    echo ==============================================================================
    echo  SUCCESS! Your app is now published live on:
    echo  - https://solariot-374e7.web.app
    echo  - https://solariot-374e7.firebaseapp.com
    echo  - And any connected custom domains (.com / .in)
    echo ==============================================================================
) else (
    COLOR 0C
    echo.
    echo [ERROR] Deployment encountered an issue. Please check the log messages above.
)

echo.
pause
