#!/usr/bin/env bash
set -e

echo "=============================================================================="
echo "       Farm.IOT / Solar.IOT - 1-Click Firebase Hosting Deployer"
echo "=============================================================================="
echo ""
echo "Target Project: solariot-374e7"
echo "Public Directory: ./dist (Pre-compiled production build)"
echo ""

if ! command -v npx &> /dev/null; then
    echo "[ERROR] Node.js / npx not found on this system."
    echo "Please install Node.js from https://nodejs.org and re-run this script."
    exit 1
fi

echo "[Step 1/2] Authenticating with Firebase..."
echo "Log into your secondary account when prompted in the browser."
npx -y firebase-tools login

echo ""
echo "[Step 2/2] Publishing to Firebase Hosting (solariot-374e7)..."
npx -y firebase-tools deploy --only hosting --project solariot-374e7

echo ""
echo "=============================================================================="
echo " SUCCESS! Your website is live:"
echo " - https://solariot-374e7.web.app"
echo " - https://solariot-374e7.firebaseapp.com"
echo "=============================================================================="
