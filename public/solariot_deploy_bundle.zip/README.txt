==============================================================================
Farm.IOT / Solar.IOT - Production Deployment Package
Target Firebase Project: solariot-374e7
==============================================================================

WHAT IS IN THIS FOLDER:
-----------------------
1. dist/          : Complete pre-built, production-optimized React web app.
2. firebase.json  : Hosting configuration with single-page app rewrites.
3. .firebaserc    : Pre-configured project alias for solariot-374e7.
4. deploy.bat     : 1-Click double-clickable deploy script for Windows.
5. deploy.sh      : 1-Click deploy script for Mac / Linux.

HOW TO DEPLOY (3 EASY STEPS):
-----------------------------
1. Extract all files in this ZIP folder to any location on your PC or laptop.
2. Ensure Node.js is installed on your computer (download free at https://nodejs.org if needed).
3. Run the deploy script:
   - On Windows: Double-click 'deploy.bat'
   - On Mac/Linux: Open Terminal in this folder and run 'bash deploy.sh'

AUTHENTICATION:
---------------
When you run the deploy script for the first time, a web browser tab will open asking you to sign in with your Google / Firebase account.
Sign in with the secondary Google account that owns the 'solariot-374e7' Firebase project.

ONCE DEPLOYED:
--------------
Your app will be immediately accessible worldwide at:
- https://solariot-374e7.web.app
- https://solariot-374e7.firebaseapp.com
- Any custom domain (.com or .in) you connect in the Firebase Console!

Note: Your hardware ESP8266 / NodeMCU microcontrollers will automatically communicate with the deployed web app through the configured cloud database bridge.
==============================================================================
